## Visualizing Animated Data with PowerPoint

[![Visualizing animated data with PowerPoint](https://i.ytimg.com/vi_webp/umHlPDFVWr0/sddefault.webp)](https://youtu.be/umHlPDFVWr0)

- [How to make a bar chart race in PowerPoint](https://blog.gramener.com/bar-chart-race-in-powerpoint/)
