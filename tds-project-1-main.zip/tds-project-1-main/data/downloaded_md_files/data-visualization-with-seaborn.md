## Data Visualization with Seaborn

[Seaborn](https://seaborn.pydata.org/) is a data visualization library for Python. It's based on Matplotlib but a bit easier to use, and a bit prettier.

[![Seaborn Tutorial : Seaborn Full Course](https://i.ytimg.com/vi_webp/6GUZXDef2U0/sddefault.webp)](https://youtu.be/6GUZXDef2U0)
