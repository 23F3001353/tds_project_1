## Visualizing Network Data with Kumu

[![Visualizing network data with Kumu](https://i.ytimg.com/vi_webp/OndB17bigkc/sddefault.webp)](https://youtu.be/OndB17bigkc)

- [Kumu](https://kumu.io)
- [IMDB data](https://developer.imdb.com/non-commercial-datasets/)
- [Jupyter Notebook](https://colab.research.google.com/drive/1CHR68fw7lZC9H2JtVW4LXpUvNwfM_VE-?usp=sharing)

[![Network analysis – filtering by year](https://i.ytimg.com/vi_webp/oi4fDzqsCes/sddefault.webp)](https://youtu.be/oi4fDzqsCes)
