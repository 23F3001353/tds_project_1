## Splitting Text in Excel

[![Convert text-to-columns in Excel](https://i.ytimg.com/vi_webp/fQeADnqiOAg/sddefault.webp)](https://youtu.be/fQeADnqiOAg)

You'll learn how to transform a single-column data set into multiple, organized columns based on specific delimiters using the "Text to Columns" feature.

Here are links used in the video:

- [US Senate Legislation - Votes](https://www.senate.gov/legislative/votes_new.htm)
