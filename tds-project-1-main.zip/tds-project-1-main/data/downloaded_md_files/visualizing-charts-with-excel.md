## Visualizing Charts with Excel

[![Visualizing charts with Google Data StudioTools to visualize numbers](https://i.ytimg.com/vi_webp/sORnCj52COw/sddefault.webp)](https://youtu.be/sORnCj52COw?t=1813s)
