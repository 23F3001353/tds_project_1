## Narratives with Excel

[![Narratives with Excel](https://i.ytimg.com/vi_webp/CRNJerr3pI4/sddefault.webp)](https://youtu.be/CRNJerr3pI4)

- [Sample Excel](https://docs.google.com/spreadsheets/d/1Htmr5ar0ZX2nYW8Xerr9OaLJl3zS0gxY/view#gid=171350107)
