## Visualizing Animated Data with Flourish

[![Visualizing animated data with Flourish](https://i.ytimg.com/vi_webp/JrnIu5Bm8i4/sddefault.webp)](https://youtu.be/JrnIu5Bm8i4)
