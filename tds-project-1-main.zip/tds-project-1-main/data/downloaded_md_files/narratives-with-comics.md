## Narratives with Comics

[![Comic narratives with Google Sheets & Comicgen](https://i.ytimg.com/vi/HZDqCQBpHGI/sddefault.jpg)](https://youtu.be/HZDqCQBpHGI)

- [Sample sheet](https://docs.google.com/spreadsheets/d/1b0DOfJnnx6MFcN955YqRqYafLb8XrH-zqtLaK2h5kkc/edit#gid=1534638946)
